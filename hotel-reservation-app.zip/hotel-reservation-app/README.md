# Hotel Room Reservation App

An internal web tool for a boutique hotel to **browse availability**, **make reservations** and **cancel reservations** across a fixed inventory (Standard ×3, Deluxe ×2, Suite ×1).

The full specification is in [`reservation-spec.md`](./reservation-spec.md). The app was built from that spec.

| Layer | Stack |
|-------|-------|
| Frontend | React 18 + Vite 5 |
| Backend | Node.js 20+ · Express 4 |
| Database | SQLite 3 (`better-sqlite3`), file at `server/data/hotel.db` |

---

## Prerequisites

- **Node.js 20 or later** and npm (check with `node -v`)

## Start the app

From the project root:

```bash
npm run setup   # installs server + client dependencies (first time only)
npm start       # builds the React UI, then starts the server
```

Open **http://localhost:3001**.

The SQLite database file is created automatically on first start and seeded with the room inventory. To reset all reservations, stop the server and delete the `server/data/` folder.

To use a different port: `PORT=4000 npm start` (macOS/Linux) or `set PORT=4000 && npm start` (Windows cmd).

## Development mode (hot reload)

Run in two terminals:

```bash
npm run dev:server   # API on http://localhost:3001
npm run dev:client   # UI on http://localhost:5173 (proxies /api to 3001)
```

## Run the tests

```bash
npm test
```

12 API tests cover every acceptance criterion in spec §11, including both validation rules.

---

## API summary

Full request/response shapes are in spec §7.

| Use case | Method & path | Success | Errors |
|----------|---------------|---------|--------|
| Browse availability | `GET /api/availability?checkIn=YYYY-MM-DD&checkOut=YYYY-MM-DD` | `200` | `400 VALIDATION_ERROR`, `400 INVALID_DATE_RANGE` |
| Make reservation | `POST /api/reservations` | `201` + reservation ID | `400 VALIDATION_ERROR`, `400 INVALID_ROOM_TYPE`, `400 INVALID_DATE_RANGE`, `409 ROOM_UNAVAILABLE` |
| Cancel reservation | `DELETE /api/reservations/{id}` | `200` | `404 RESERVATION_NOT_FOUND` |
| (supporting) List reservations | `GET /api/reservations` | `200` | — |

Quick check with curl:

```bash
curl "http://localhost:3001/api/availability?checkIn=2026-12-10&checkOut=2026-12-13"

curl -X POST http://localhost:3001/api/reservations \
  -H "Content-Type: application/json" \
  -d '{"guestName":"Asha Rao","guestEmail":"asha@example.com","roomType":"SUITE","checkInDate":"2026-12-10","checkOutDate":"2026-12-13"}'

curl -X DELETE http://localhost:3001/api/reservations/RES-XXXXXXXX
```

## Out of scope

No payment processing, no login/authentication, no editing of reservations (cancel and rebook instead), and no room photos, pricing or descriptions. See spec §2.2.

## Project layout

```
reservation-spec.md   the spec (source of truth)
server/               Express API + SQLite (src/, test/)
client/               React UI (Vite)
```
