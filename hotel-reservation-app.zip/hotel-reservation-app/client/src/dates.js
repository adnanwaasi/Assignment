// Local-date helpers producing YYYY-MM-DD strings.
const pad = (n) => String(n).padStart(2, '0');
const fmt = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

export const today = () => fmt(new Date());

export function plusDays(iso, days) {
  const [y, m, d] = iso.split('-').map(Number);
  return fmt(new Date(y, m - 1, d + days));
}
