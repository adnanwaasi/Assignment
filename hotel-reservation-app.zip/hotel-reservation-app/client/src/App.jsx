import { useCallback, useEffect, useState } from 'react';
import { api } from './api.js';
import AvailabilityPanel from './components/AvailabilityPanel.jsx';
import ReservationForm from './components/ReservationForm.jsx';
import CancelPanel from './components/CancelPanel.jsx';

export default function App() {
  const [reservations, setReservations] = useState([]);
  const [listError, setListError] = useState('');
  // Bumped after any booking/cancellation so the availability table refreshes (spec §8).
  const [version, setVersion] = useState(0);

  const loadReservations = useCallback(async () => {
    try {
      const data = await api.listReservations();
      setReservations(data.reservations);
      setListError('');
    } catch (err) {
      setListError(err.message);
    }
  }, []);

  useEffect(() => {
    loadReservations();
  }, [loadReservations, version]);

  const onChange = () => setVersion((v) => v + 1);

  return (
    <div className="page">
      <header className="masthead">
        <div>
          <p className="eyebrow">Front desk</p>
          <h1>Room Reservations</h1>
        </div>
        <ul className="inventory" aria-label="Room inventory">
          <li><span>Standard</span><strong>3</strong></li>
          <li><span>Deluxe</span><strong>2</strong></li>
          <li><span>Suite</span><strong>1</strong></li>
        </ul>
      </header>

      <main className="grid">
        <AvailabilityPanel version={version} />
        <ReservationForm onBooked={onChange} />
        <CancelPanel
          reservations={reservations}
          listError={listError}
          onCancelled={onChange}
        />
      </main>
    </div>
  );
}
