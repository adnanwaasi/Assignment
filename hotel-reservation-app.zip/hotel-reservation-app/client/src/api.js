// Thin wrapper over the REST API in reservation-spec.md §7.
// The API is authoritative: on error we surface error.message verbatim.

export class ApiRequestError extends Error {
  constructor({ code, message, field }) {
    super(message);
    this.code = code;
    this.field = field;
  }
}

async function request(method, path, body) {
  let res;
  try {
    res = await fetch(`/api${path}`, {
      method,
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiRequestError({ code: 'NETWORK_ERROR', message: 'Could not reach the server.' });
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiRequestError(
      data.error ?? { code: 'UNKNOWN', message: `Request failed (${res.status}).` },
    );
  }
  return data;
}

export const api = {
  // UC-1
  getAvailability: (checkIn, checkOut) =>
    request('GET', `/availability?${new URLSearchParams({ checkIn, checkOut })}`),
  // UC-2
  createReservation: (input) => request('POST', '/reservations', input),
  // UC-3
  cancelReservation: (id) => request('DELETE', `/reservations/${encodeURIComponent(id)}`),
  // Supporting
  listReservations: () => request('GET', '/reservations'),
};

export const ROOM_TYPES = [
  { code: 'STANDARD', name: 'Standard' },
  { code: 'DELUXE', name: 'Deluxe' },
  { code: 'SUITE', name: 'Suite' },
];

export const roomName = (code) => ROOM_TYPES.find((r) => r.code === code)?.name ?? code;
