import { useState } from 'react';
import { api, roomName } from '../api.js';

// UC-3 — Cancel reservation (spec §8, panel 3)
export default function CancelPanel({ reservations, listError, onCancelled }) {
  const [id, setId] = useState('');
  const [message, setMessage] = useState(null); // { kind: 'success' | 'error', text }
  const [busy, setBusy] = useState(false);

  async function cancel(targetId) {
    const trimmed = targetId.trim();
    if (!trimmed) return;
    setBusy(true);
    try {
      const res = await api.cancelReservation(trimmed);
      setMessage({ kind: 'success', text: res.message });
      setId('');
      onCancelled();
    } catch (err) {
      setMessage({ kind: 'error', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="panel wide">
      <h2><span className="step">3</span>Cancel reservation</h2>
      <form
        className="row"
        onSubmit={(e) => {
          e.preventDefault();
          cancel(id);
        }}
      >
        <label className="grow">
          Reservation ID
          <input
            value={id}
            onChange={(e) => setId(e.target.value)}
            placeholder="RES-XXXXXXXX"
            required
          />
        </label>
        <button type="submit" className="danger" disabled={busy}>Cancel reservation</button>
      </form>

      {message && (
        <p className={`alert ${message.kind}`} role={message.kind === 'error' ? 'alert' : 'status'}>
          {message.text}
        </p>
      )}

      <h3>Current reservations</h3>
      {listError && <p className="alert error">{listError}</p>}
      {reservations.length === 0 ? (
        <p className="muted">No reservations yet.</p>
      ) : (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>ID</th>
                <th>Guest</th>
                <th>Email</th>
                <th>Room</th>
                <th>Check-in</th>
                <th>Check-out</th>
                <th aria-label="Actions" />
              </tr>
            </thead>
            <tbody>
              {reservations.map((r) => (
                <tr key={r.id}>
                  <td className="mono">{r.id}</td>
                  <td>{r.guestName}</td>
                  <td>{r.guestEmail}</td>
                  <td>{roomName(r.roomType)}</td>
                  <td>{r.checkInDate}</td>
                  <td>{r.checkOutDate}</td>
                  <td>
                    <button type="button" className="link-danger" disabled={busy} onClick={() => cancel(r.id)}>
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
