import { useState } from 'react';
import { api, ROOM_TYPES, roomName } from '../api.js';
import { today, plusDays } from '../dates.js';

const emptyForm = () => ({
  guestName: '',
  guestEmail: '',
  roomType: 'STANDARD',
  checkInDate: today(),
  checkOutDate: plusDays(today(), 1),
});

// UC-2 — Make reservation (spec §8, panel 2)
export default function ReservationForm({ onBooked }) {
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState(null);
  const [confirmed, setConfirmed] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const set = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setSubmitting(true);
    setError(null);
    setConfirmed(null);
    try {
      const { reservation } = await api.createReservation(form);
      setConfirmed(reservation);
      setForm(emptyForm());
      onBooked();
    } catch (err) {
      setError(err);
    } finally {
      setSubmitting(false);
    }
  }

  const invalid = (field) => (error?.field === field ? 'invalid' : undefined);

  return (
    <section className="panel">
      <h2><span className="step">2</span>Make reservation</h2>
      <form className="stack" onSubmit={submit}>
        <label>
          Guest name
          <input value={form.guestName} onChange={set('guestName')} className={invalid('guestName')} required />
        </label>
        <label>
          Guest email
          <input value={form.guestEmail} onChange={set('guestEmail')} className={invalid('guestEmail')} required />
        </label>
        <label>
          Room type
          <select value={form.roomType} onChange={set('roomType')} className={invalid('roomType')}>
            {ROOM_TYPES.map((r) => (
              <option key={r.code} value={r.code}>{r.name}</option>
            ))}
          </select>
        </label>
        <div className="row">
          <label>
            Check-in
            <input type="date" value={form.checkInDate} onChange={set('checkInDate')} className={invalid('checkInDate')} required />
          </label>
          <label>
            Check-out
            <input type="date" value={form.checkOutDate} onChange={set('checkOutDate')} className={invalid('checkOutDate')} required />
          </label>
        </div>
        <button type="submit" disabled={submitting}>
          {submitting ? 'Reserving…' : 'Reserve'}
        </button>
      </form>

      {error && <p className="alert error" role="alert">{error.message}</p>}

      {confirmed && (
        <div className="alert success" role="status">
          <p>Reservation confirmed</p>
          <p className="res-id">{confirmed.id}</p>
          <p className="muted">
            {confirmed.guestName} · {roomName(confirmed.roomType)} · {confirmed.checkInDate} → {confirmed.checkOutDate}
          </p>
        </div>
      )}
    </section>
  );
}
