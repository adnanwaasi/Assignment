import { useEffect, useState } from 'react';
import { api } from '../api.js';
import { today, plusDays } from '../dates.js';

// UC-1 — Browse availability (spec §8, panel 1)
export default function AvailabilityPanel({ version }) {
  const [checkIn, setCheckIn] = useState(today());
  const [checkOut, setCheckOut] = useState(plusDays(today(), 1));
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function load(ci = checkIn, co = checkOut) {
    setLoading(true);
    try {
      setResult(await api.getAvailability(ci, co));
      setError('');
    } catch (err) {
      setResult(null);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  // Refresh the table after bookings/cancellations, if a search has been made.
  useEffect(() => {
    if (result) load(result.checkIn, result.checkOut);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [version]);

  return (
    <section className="panel">
      <h2><span className="step">1</span>Browse availability</h2>
      <form
        className="row"
        onSubmit={(e) => {
          e.preventDefault();
          load();
        }}
      >
        <label>
          Check-in
          <input type="date" value={checkIn} onChange={(e) => setCheckIn(e.target.value)} required />
        </label>
        <label>
          Check-out
          <input type="date" value={checkOut} onChange={(e) => setCheckOut(e.target.value)} required />
        </label>
        <button type="submit" disabled={loading}>
          {loading ? 'Checking…' : 'Check availability'}
        </button>
      </form>

      {error && <p className="alert error" role="alert">{error}</p>}

      {result && (
        <>
          <p className="muted">
            {result.checkIn} → {result.checkOut} · {result.nights} night{result.nights === 1 ? '' : 's'}
          </p>
          <table>
            <thead>
              <tr>
                <th>Room type</th>
                <th className="num">Total units</th>
                <th className="num">Available</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {result.roomTypes.map((r) => (
                <tr key={r.roomType}>
                  <td>{r.name}</td>
                  <td className="num">{r.totalUnits}</td>
                  <td className="num"><strong>{r.availableUnits}</strong></td>
                  <td>
                    <span className={`badge ${r.available ? 'ok' : 'full'}`}>
                      {r.available ? 'Available' : 'Fully booked'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
    </section>
  );
}
