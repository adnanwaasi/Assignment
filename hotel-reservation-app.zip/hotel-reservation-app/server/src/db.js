// SQLite connection, schema and seed — see reservation-spec.md §4 and §5.3.
import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

// Fixed room inventory (spec §4). Order here is the display order.
export const ROOM_INVENTORY = [
  { code: 'STANDARD', name: 'Standard', totalUnits: 3 },
  { code: 'DELUXE', name: 'Deluxe', totalUnits: 2 },
  { code: 'SUITE', name: 'Suite', totalUnits: 1 },
];

const SCHEMA = `
CREATE TABLE IF NOT EXISTS room_types (
  code        TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  total_units INTEGER NOT NULL CHECK (total_units > 0)
);

CREATE TABLE IF NOT EXISTS reservations (
  id             TEXT PRIMARY KEY,
  guest_name     TEXT NOT NULL,
  guest_email    TEXT NOT NULL,
  room_type      TEXT NOT NULL REFERENCES room_types(code),
  check_in_date  TEXT NOT NULL,
  check_out_date TEXT NOT NULL,
  created_at     TEXT NOT NULL,
  CHECK (check_in_date < check_out_date)
);

CREATE INDEX IF NOT EXISTS idx_reservations_type_dates
  ON reservations (room_type, check_in_date, check_out_date);
`;

/**
 * Opens (and if needed creates) the database.
 * @param {string} filename path to the .db file, or ':memory:' for tests
 */
export function openDatabase(filename) {
  if (filename !== ':memory:') {
    fs.mkdirSync(path.dirname(filename), { recursive: true });
  }
  const db = new Database(filename);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.exec(SCHEMA);

  // Seed / re-assert the fixed inventory so it always matches the spec.
  const upsert = db.prepare(`
    INSERT INTO room_types (code, name, total_units) VALUES (@code, @name, @totalUnits)
    ON CONFLICT(code) DO UPDATE SET name = excluded.name, total_units = excluded.total_units
  `);
  db.transaction(() => ROOM_INVENTORY.forEach((r) => upsert.run(r)))();

  return db;
}
