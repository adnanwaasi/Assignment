// Availability calculation — see reservation-spec.md §6.1–§6.3.

/**
 * Peak number of reservations of one room type that cover any single night
 * in the half-open range [checkIn, checkOut).
 *
 * Uses a sweep over start/end events: +1 when a stay starts, −1 when it ends.
 * Ends are processed before starts on the same date, because the check-out
 * day is not an occupied night.
 */
export function peakReserved(db, roomType, checkIn, checkOut) {
  const overlapping = db
    .prepare(
      `SELECT check_in_date AS checkIn, check_out_date AS checkOut
         FROM reservations
        WHERE room_type = ?
          AND check_in_date < ?
          AND check_out_date > ?`,
    )
    .all(roomType, checkOut, checkIn);

  const events = [];
  for (const r of overlapping) {
    const start = r.checkIn > checkIn ? r.checkIn : checkIn;
    const end = r.checkOut < checkOut ? r.checkOut : checkOut;
    events.push([start, +1], [end, -1]);
  }
  events.sort((a, b) => (a[0] === b[0] ? a[1] - b[1] : a[0] < b[0] ? -1 : 1));

  let current = 0;
  let peak = 0;
  for (const [, delta] of events) {
    current += delta;
    if (current > peak) peak = current;
  }
  return peak;
}

/** Availability for every room type over [checkIn, checkOut). */
export function getAvailability(db, checkIn, checkOut) {
  const roomTypes = db
    .prepare('SELECT code, name, total_units AS totalUnits FROM room_types')
    .all();
  const order = ['STANDARD', 'DELUXE', 'SUITE'];
  roomTypes.sort((a, b) => order.indexOf(a.code) - order.indexOf(b.code));

  return roomTypes.map((rt) => {
    const availableUnits = Math.max(0, rt.totalUnits - peakReserved(db, rt.code, checkIn, checkOut));
    return {
      roomType: rt.code,
      name: rt.name,
      totalUnits: rt.totalUnits,
      availableUnits,
      available: availableUnits > 0,
    };
  });
}
