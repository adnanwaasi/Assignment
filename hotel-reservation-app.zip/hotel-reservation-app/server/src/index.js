// Entry point — starts the HTTP server.
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { openDatabase } from './db.js';
import { createApp } from './app.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3001;
const DB_FILE = process.env.DB_FILE || path.join(here, '..', 'data', 'hotel.db');
const STATIC_DIR = path.join(here, '..', '..', 'client', 'dist');

const db = openDatabase(DB_FILE);
const app = createApp(db, { staticDir: STATIC_DIR });

app.listen(PORT, () => {
  console.log(`Hotel Reservation API listening on http://localhost:${PORT}`);
  console.log(`Database: ${DB_FILE}`);
});
