// Express app and routes — see reservation-spec.md §7.
import express from 'express';
import crypto from 'node:crypto';
import fs from 'node:fs';
import { ApiError, ErrorCodes } from './errors.js';
import { getAvailability, peakReserved } from './availability.js';
import {
  nightsBetween,
  requireDate,
  requireDateOrder,
  validateReservationInput,
} from './validation.js';

const ROW_TO_RESERVATION = `
  id, guest_name AS guestName, guest_email AS guestEmail, room_type AS roomType,
  check_in_date AS checkInDate, check_out_date AS checkOutDate, created_at AS createdAt
`;

function newReservationId() {
  return `RES-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
}

/**
 * @param {import('better-sqlite3').Database} db
 * @param {{ staticDir?: string }} [options] directory of the built React app to serve
 */
export function createApp(db, options = {}) {
  const app = express();
  app.use(express.json());

  const api = express.Router();

  // UC-1 — Browse availability (spec §7.2)
  api.get('/availability', (req, res) => {
    const { checkIn, checkOut } = req.query;
    requireDate(checkIn, 'checkIn');
    requireDate(checkOut, 'checkOut');
    requireDateOrder(checkIn, checkOut, 'checkOut'); // VR-1
    res.json({
      checkIn,
      checkOut,
      nights: nightsBetween(checkIn, checkOut),
      roomTypes: getAvailability(db, checkIn, checkOut),
    });
  });

  // Supporting — list reservations (spec §7.5)
  api.get('/reservations', (_req, res) => {
    const reservations = db
      .prepare(`SELECT ${ROW_TO_RESERVATION} FROM reservations ORDER BY check_in_date, created_at`)
      .all();
    res.json({ reservations });
  });

  // UC-2 — Make reservation (spec §7.3)
  const insert = db.prepare(`
    INSERT INTO reservations (id, guest_name, guest_email, room_type, check_in_date, check_out_date, created_at)
    VALUES (@id, @guestName, @guestEmail, @roomType, @checkInDate, @checkOutDate, @createdAt)
  `);
  const idExists = db.prepare('SELECT 1 FROM reservations WHERE id = ?');
  const roomType = db.prepare('SELECT name, total_units AS totalUnits FROM room_types WHERE code = ?');

  // Availability check + insert in one transaction (spec §6.4)
  const bookTransaction = db.transaction((input) => {
    const rt = roomType.get(input.roomType);
    const reserved = peakReserved(db, input.roomType, input.checkInDate, input.checkOutDate);
    if (reserved >= rt.totalUnits) {
      // VR-2
      throw new ApiError(
        ErrorCodes.ROOM_UNAVAILABLE,
        `No ${rt.name} rooms are available from ${input.checkInDate} to ${input.checkOutDate}. ` +
          `All ${rt.totalUnits} unit(s) are already reserved for overlapping dates.`,
        'roomType',
      );
    }
    let id;
    do {
      id = newReservationId();
    } while (idExists.get(id));
    const reservation = { id, ...input, createdAt: new Date().toISOString() };
    insert.run(reservation);
    return reservation;
  });

  api.post('/reservations', (req, res) => {
    const input = validateReservationInput(req.body);
    const reservation = bookTransaction.immediate(input);
    res.status(201).json({ reservation });
  });

  // UC-3 — Cancel reservation (spec §7.4)
  const remove = db.prepare('DELETE FROM reservations WHERE id = ?');
  api.delete('/reservations/:id', (req, res) => {
    const { id } = req.params;
    const result = remove.run(id);
    if (result.changes === 0) {
      throw new ApiError(ErrorCodes.RESERVATION_NOT_FOUND, `Reservation ${id} was not found.`);
    }
    res.json({ id, message: `Reservation ${id} has been cancelled.` });
  });

  // Anything else under /api (including PUT/PATCH — modification is out of scope)
  api.all('*', (req) => {
    throw new ApiError(ErrorCodes.NOT_FOUND, `No route for ${req.method} ${req.originalUrl}.`);
  });

  app.use('/api', api);

  // Serve the built React app in production mode (spec §9)
  if (options.staticDir && fs.existsSync(options.staticDir)) {
    app.use(express.static(options.staticDir));
    app.get('*', (_req, res) => res.sendFile('index.html', { root: options.staticDir }));
  }

  // Error handler — every error uses the shape in spec §7.1
  // eslint-disable-next-line no-unused-vars
  app.use((err, _req, res, _next) => {
    if (err instanceof ApiError) {
      return res.status(err.status).json(err.toJSON());
    }
    if (err?.type === 'entity.parse.failed') {
      const e = new ApiError(ErrorCodes.VALIDATION_ERROR, 'Request body must be valid JSON.');
      return res.status(e.status).json(e.toJSON());
    }
    console.error(err);
    const e = new ApiError(ErrorCodes.INTERNAL_ERROR, 'An unexpected error occurred.');
    return res.status(e.status).json(e.toJSON());
  });

  return app;
}
