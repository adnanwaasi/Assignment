// Request validation helpers — see reservation-spec.md §6.
import { ApiError, ErrorCodes } from './errors.js';
import { ROOM_INVENTORY } from './db.js';

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

/** True when value is a real calendar date in YYYY-MM-DD form (VR-4). */
export function isValidIsoDate(value) {
  if (typeof value !== 'string' || !DATE_PATTERN.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number);
  const date = new Date(Date.UTC(y, m - 1, d));
  return (
    date.getUTCFullYear() === y &&
    date.getUTCMonth() === m - 1 &&
    date.getUTCDate() === d
  );
}

/** Number of nights between two valid ISO dates. */
export function nightsBetween(checkIn, checkOut) {
  return Math.round((Date.parse(checkOut) - Date.parse(checkIn)) / 86_400_000);
}

function isBlank(value) {
  return value === undefined || value === null || String(value).trim() === '';
}

/** VR-4: both dates present and valid. */
export function requireDate(value, field) {
  if (isBlank(value)) {
    throw new ApiError(ErrorCodes.VALIDATION_ERROR, `${field} is required.`, field);
  }
  if (!isValidIsoDate(value)) {
    throw new ApiError(
      ErrorCodes.VALIDATION_ERROR,
      `${field} must be a valid date in YYYY-MM-DD format.`,
      field,
    );
  }
}

/** VR-1: check-in strictly before check-out. */
export function requireDateOrder(checkIn, checkOut, checkOutField) {
  // ISO YYYY-MM-DD strings compare correctly as strings.
  if (!(checkIn < checkOut)) {
    throw new ApiError(
      ErrorCodes.INVALID_DATE_RANGE,
      'Check-in date must be strictly before check-out date.',
      checkOutField,
    );
  }
}

/**
 * Validates a POST /api/reservations body in the order given by spec §6.4
 * (steps 1–5). Returns the normalised reservation input.
 */
export function validateReservationInput(body) {
  // Step 1 — body must be a JSON object
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    throw new ApiError(ErrorCodes.VALIDATION_ERROR, 'Request body must be a JSON object.');
  }

  const { guestName, guestEmail, roomType, checkInDate, checkOutDate } = body;

  // Step 2 — VR-3 required fields (email: presence only, no format check)
  const required = { guestName, guestEmail, roomType, checkInDate, checkOutDate };
  for (const [field, value] of Object.entries(required)) {
    if (isBlank(value)) {
      throw new ApiError(ErrorCodes.VALIDATION_ERROR, `${field} is required.`, field);
    }
  }
  for (const field of ['guestName', 'guestEmail', 'roomType']) {
    if (typeof required[field] !== 'string') {
      throw new ApiError(ErrorCodes.VALIDATION_ERROR, `${field} must be a string.`, field);
    }
  }

  // Step 3 — VR-4 date format
  requireDate(checkInDate, 'checkInDate');
  requireDate(checkOutDate, 'checkOutDate');

  // Step 4 — VR-5 room type
  if (!ROOM_INVENTORY.some((r) => r.code === roomType)) {
    throw new ApiError(
      ErrorCodes.INVALID_ROOM_TYPE,
      `roomType must be one of ${ROOM_INVENTORY.map((r) => r.code).join(', ')}.`,
      'roomType',
    );
  }

  // Step 5 — VR-1 date order
  requireDateOrder(checkInDate, checkOutDate, 'checkOutDate');

  return {
    guestName: guestName.trim(),
    guestEmail: guestEmail.trim(),
    roomType,
    checkInDate,
    checkOutDate,
  };
}
