// Error codes and the ApiError class — see reservation-spec.md §7.1 and §7.6.

export const ErrorCodes = Object.freeze({
  VALIDATION_ERROR: { code: 'VALIDATION_ERROR', status: 400 },
  INVALID_ROOM_TYPE: { code: 'INVALID_ROOM_TYPE', status: 400 },
  INVALID_DATE_RANGE: { code: 'INVALID_DATE_RANGE', status: 400 },
  ROOM_UNAVAILABLE: { code: 'ROOM_UNAVAILABLE', status: 409 },
  RESERVATION_NOT_FOUND: { code: 'RESERVATION_NOT_FOUND', status: 404 },
  NOT_FOUND: { code: 'NOT_FOUND', status: 404 },
  INTERNAL_ERROR: { code: 'INTERNAL_ERROR', status: 500 },
});

export class ApiError extends Error {
  constructor(type, message, field) {
    super(message);
    this.status = type.status;
    this.code = type.code;
    this.field = field;
  }

  toJSON() {
    const error = { code: this.code, message: this.message };
    if (this.field) error.field = this.field;
    return { error };
  }
}
