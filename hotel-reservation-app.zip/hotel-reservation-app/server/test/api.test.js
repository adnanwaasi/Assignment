// API tests mapped to the acceptance criteria in reservation-spec.md §11.
import { test, beforeEach, afterEach } from 'node:test';
import assert from 'node:assert/strict';
import { openDatabase } from '../src/db.js';
import { createApp } from '../src/app.js';

let server;
let base;

beforeEach(async () => {
  const app = createApp(openDatabase(':memory:'));
  await new Promise((resolve) => {
    server = app.listen(0, resolve);
  });
  base = `http://127.0.0.1:${server.address().port}/api`;
});

afterEach(() => new Promise((resolve) => server.close(resolve)));

const json = (method, path, body) =>
  fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body),
  }).then(async (r) => ({ status: r.status, body: await r.json() }));

const book = (overrides = {}) =>
  json('POST', '/reservations', {
    guestName: 'Asha Rao',
    guestEmail: 'asha@example.com',
    roomType: 'SUITE',
    checkInDate: '2026-12-10',
    checkOutDate: '2026-12-13',
    ...overrides,
  });

const availability = (checkIn, checkOut) =>
  json('GET', `/availability?checkIn=${checkIn}&checkOut=${checkOut}`);

const unitsOf = (res, type) => res.body.roomTypes.find((r) => r.roomType === type).availableUnits;

test('AC-1: empty database shows full inventory', async () => {
  const res = await availability('2026-12-10', '2026-12-13');
  assert.equal(res.status, 200);
  assert.equal(res.body.nights, 3);
  assert.deepEqual(
    res.body.roomTypes.map((r) => [r.roomType, r.name, r.totalUnits, r.availableUnits, r.available]),
    [
      ['STANDARD', 'Standard', 3, 3, true],
      ['DELUXE', 'Deluxe', 2, 2, true],
      ['SUITE', 'Suite', 1, 1, true],
    ],
  );
});

test('AC-2: valid reservation returns 201 with unique ID and reduces availability', async () => {
  const res = await book({ roomType: 'DELUXE' });
  assert.equal(res.status, 201);
  assert.match(res.body.reservation.id, /^RES-[0-9A-F]{8}$/);
  assert.equal(res.body.reservation.guestName, 'Asha Rao');
  assert.equal(res.body.reservation.roomType, 'DELUXE');
  assert.ok(res.body.reservation.createdAt);

  const second = await book({ roomType: 'DELUXE' });
  assert.notEqual(second.body.reservation.id, res.body.reservation.id);

  assert.equal(unitsOf(await availability('2026-12-11', '2026-12-12'), 'DELUXE'), 0);
  assert.equal(unitsOf(await availability('2026-12-13', '2026-12-14'), 'DELUXE'), 2);
});

test('AC-3 / VR-1: check-in must be strictly before check-out', async () => {
  for (const [checkInDate, checkOutDate] of [
    ['2026-12-10', '2026-12-10'],
    ['2026-12-12', '2026-12-10'],
  ]) {
    const res = await book({ checkInDate, checkOutDate });
    assert.equal(res.status, 400);
    assert.deepEqual(res.body, {
      error: {
        code: 'INVALID_DATE_RANGE',
        message: 'Check-in date must be strictly before check-out date.',
        field: 'checkOutDate',
      },
    });
  }
  const list = await json('GET', '/reservations');
  assert.equal(list.body.reservations.length, 0);

  const avail = await availability('2026-12-10', '2026-12-10');
  assert.equal(avail.status, 400);
  assert.equal(avail.body.error.code, 'INVALID_DATE_RANGE');
  assert.equal(avail.body.error.field, 'checkOut');
});

test('AC-4 / VR-2: fully booked room type is rejected for overlapping dates', async () => {
  assert.equal((await book()).status, 201); // Suite 10–13
  const res = await book({ checkInDate: '2026-12-12', checkOutDate: '2026-12-14' });
  assert.equal(res.status, 409);
  assert.equal(res.body.error.code, 'ROOM_UNAVAILABLE');
  assert.equal(res.body.error.field, 'roomType');
  assert.match(res.body.error.message, /No Suite rooms are available/);
});

test('AC-5: check-out day is free for the next guest', async () => {
  assert.equal((await book()).status, 201); // Suite 10–13
  assert.equal((await book({ checkInDate: '2026-12-13', checkOutDate: '2026-12-15' })).status, 201);
  assert.equal((await book({ checkInDate: '2026-12-08', checkOutDate: '2026-12-10' })).status, 201);
});

test('VR-2 uses per-night peak: back-to-back stays do not block a third unit', async () => {
  // Standard has 3 units. Two back-to-back stays + one long stay = max 2 per night.
  await book({ roomType: 'STANDARD', checkInDate: '2026-12-01', checkOutDate: '2026-12-03' });
  await book({ roomType: 'STANDARD', checkInDate: '2026-12-03', checkOutDate: '2026-12-05' });
  await book({ roomType: 'STANDARD', checkInDate: '2026-12-01', checkOutDate: '2026-12-05' });
  assert.equal(unitsOf(await availability('2026-12-01', '2026-12-05'), 'STANDARD'), 1);
  assert.equal(
    (await book({ roomType: 'STANDARD', checkInDate: '2026-12-01', checkOutDate: '2026-12-05' })).status,
    201,
  );
  const full = await book({ roomType: 'STANDARD', checkInDate: '2026-12-02', checkOutDate: '2026-12-03' });
  assert.equal(full.status, 409);
});

test('AC-6: guest email is required, presence only', async () => {
  const missing = await book({ guestEmail: undefined });
  assert.equal(missing.status, 400);
  assert.deepEqual(missing.body.error, {
    code: 'VALIDATION_ERROR',
    message: 'guestEmail is required.',
    field: 'guestEmail',
  });
  const blank = await book({ guestEmail: '   ' });
  assert.equal(blank.body.error.field, 'guestEmail');
  const noFormat = await book({ guestEmail: 'abc' });
  assert.equal(noFormat.status, 201);
});

test('other validation errors: missing name, bad date, bad room type, bad JSON', async () => {
  assert.equal((await book({ guestName: '' })).body.error.field, 'guestName');

  const badDate = await book({ checkInDate: '2026-02-30' });
  assert.equal(badDate.status, 400);
  assert.equal(badDate.body.error.code, 'VALIDATION_ERROR');
  assert.equal(badDate.body.error.field, 'checkInDate');

  const badType = await book({ roomType: 'PENTHOUSE' });
  assert.equal(badType.status, 400);
  assert.equal(badType.body.error.code, 'INVALID_ROOM_TYPE');

  const raw = await fetch(`${base}/reservations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: '{not json',
  });
  assert.equal(raw.status, 400);
  assert.equal((await raw.json()).error.code, 'VALIDATION_ERROR');

  const missingQuery = await json('GET', '/availability?checkIn=2026-12-10');
  assert.equal(missingQuery.status, 400);
  assert.equal(missingQuery.body.error.field, 'checkOut');
});

test('AC-7: cancelling frees the unit', async () => {
  const { body } = await book();
  const id = body.reservation.id;
  assert.equal(unitsOf(await availability('2026-12-10', '2026-12-13'), 'SUITE'), 0);

  const res = await json('DELETE', `/reservations/${id}`);
  assert.equal(res.status, 200);
  assert.deepEqual(res.body, { id, message: `Reservation ${id} has been cancelled.` });
  assert.equal(unitsOf(await availability('2026-12-10', '2026-12-13'), 'SUITE'), 1);
});

test('AC-8: cancelling an unknown ID returns 404', async () => {
  const res = await json('DELETE', '/reservations/RES-00000000');
  assert.equal(res.status, 404);
  assert.deepEqual(res.body, {
    error: { code: 'RESERVATION_NOT_FOUND', message: 'Reservation RES-00000000 was not found.' },
  });
});

test('AC-9: no modification endpoint exists', async () => {
  const { body } = await book();
  const id = body.reservation.id;
  for (const method of ['PUT', 'PATCH']) {
    const res = await json(method, `/reservations/${id}`, { guestName: 'Changed' });
    assert.equal(res.status, 404);
    assert.equal(res.body.error.code, 'NOT_FOUND');
  }
});

test('list reservations returns stored records sorted by check-in', async () => {
  await book({ roomType: 'STANDARD', checkInDate: '2026-12-20', checkOutDate: '2026-12-21' });
  await book({ roomType: 'STANDARD', checkInDate: '2026-12-05', checkOutDate: '2026-12-06' });
  const res = await json('GET', '/reservations');
  assert.equal(res.status, 200);
  assert.deepEqual(
    res.body.reservations.map((r) => r.checkInDate),
    ['2026-12-05', '2026-12-20'],
  );
});
